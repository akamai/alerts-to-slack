# Alerts to Slack

This code integrates the Akamai Alerts system with Slack, making it possible to receive your alert messages where you spend your time.
