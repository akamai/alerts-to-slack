import requests, logging, json, sys
from akamai.edgegrid import EdgeGridAuth
session = requests.Session()
section_name = "alerts"
import os

from urllib import parse

print ("Setting up function now")
env_prefix = '_'.join(['AKAMAI',section_name.upper()])
env = {}
for token in ('CLIENT_TOKEN','CLIENT_SECRET','ACCESS_TOKEN','HOST'):
	env_string = '_'.join([env_prefix, token])
	if env_string not in os.environ:
		print ("Need to set environment variables: %s" % env_string)
		continue
	env[token] = os.environ[env_string]

if len(env) < 4:
	exit(0)

print (env)

# Set the config options
session.auth = EdgeGridAuth(
            client_token=env['CLIENT_TOKEN'],
            client_secret=env['CLIENT_SECRET'],
            access_token=env['ACCESS_TOKEN']
)

baseurl = '%s://%s/' % ('https', env['HOST'])

def handler(event, context):
	#alert_result = session.get(parse.urljoin(baseurl,'/alerts/v2/alert-definitions'))
	#print (alert_result.json())
	return(env)

